# možda dodati izbor jezika
# možda dodati ispis prvih 10 rezultata queryja
# dodati postavke Usera
