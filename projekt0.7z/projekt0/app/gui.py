# Aplikacija korisniku koji nije ulogiran prikazuje datum, grad  po vašem odabiru i prognozu za njega dohvaćenu sa: Weather Forecast API | Open-Meteo.com

import tkinter as tk
from api import print_data_for_other_locations
from database import session, User, Data
from RaspberryPi import temp_class, humid_class, press_class
from json_save import save_as_dict, save_as_json
from tkcalendar import DateEntry
from datetime import datetime
import matplotlib.pyplot as plt
import numpy as np



root = tk.Tk()
root.title("WeatherApp")
root.geometry("800x600")

########## FUNKCIJE ##############
def log_in():
    """
    Checks if user exists. If no user exists, sends a message to terminal.
    If the password is wrong, sends a message to terminal.
    If log in is successful, draws sensors window.
    """
    global username
    global newWindow
    username = session.query(User).filter(User.username==username_e.get()).first()
    
    if not username:
        print("No specified username exists")
    elif  username.password != password_e.get():
        print("Wrong password")
    else:
        newWindow = tk.Toplevel(root)
        
        check = tk.Label(newWindow, text="Uspjesan login")
        check.grid(row=0, column=0)
        sensors_window()

def change_weather_location():

    """
    Changes the location from default to the typed in location in the log in window.
    """
    global temp
    temp.destroy()
    temp = tk.Label(root, text=print_data_for_other_locations(location.get()))
    temp.grid(row=0, column=2)

def user_settings():
    """
    Changes the default user settings from the sign up window.
    """
    global password_old
    global password_new

    global def_temp_entry
    global def_hum_entry
    global def_press_entry
    global def_sensor_location_entry

    settings_window = tk.Toplevel(newWindow)

    save_button = tk.Button(settings_window, text="Save Changes", command= save_changes)

    def_temp_entry = tk.Entry(settings_window)
    def_hum_entry = tk.Entry(settings_window)
    def_press_entry = tk.Entry(settings_window)
    def_sensor_location_entry = tk.Entry(settings_window)

    temp_low_dif = tk.Entry(settings_window, width=5)
    temp_mid_dif = tk.Entry(settings_window, width=5)
    humid_low_dif = tk.Entry(settings_window, width=5)
    humid_mid_dif = tk.Entry(settings_window, width=5)
    press_low_dif = tk.Entry(settings_window, width=5)
    press_mid_dif = tk.Entry(settings_window, width=5)
    password_old = tk.Entry(settings_window, width= 5, show='*')
    password_new = tk.Entry(settings_window, width=5, show='*')

    password_old_label = tk.Label(settings_window, text="Enter Old Password")
    password_new_label = tk.Label(settings_window, text="Enter New Password")
    def_sensor_location_entry_label = tk.Label(settings_window, text="Sensor Location")
    def_temp_entry_label = tk.Label(settings_window, text="Default Temperature")
    def_hum_entry_label  = tk.Label(settings_window, text="Default Humidity")
    def_press_entry_label  = tk.Label(settings_window, text="Default Pressure")

    temp_low_dif_label = tk.Label(settings_window, text="T small")
    temp_mid_dif_label = tk.Label(settings_window, text="T mid")
    humid_low_dif_label = tk.Label(settings_window, text="H small")
    humid_mid_dif_label = tk.Label(settings_window, text="H mid")
    press_low_dif_label = tk.Label(settings_window, text="P small")
    press_mid_dif_label = tk.Label(settings_window, text="P mid")

    save_button.grid(row=5, column=0)

    password_old.grid(row=1, column=1)
    password_new.grid(row=2, column=1)
    def_temp_entry.grid(row=4, column=1)
    def_hum_entry.grid(row=4, column=2)
    def_press_entry.grid(row=4, column=3)
    def_sensor_location_entry.grid(row= 4, column= 0)

    temp_low_dif.grid(row=8, column=0)
    temp_mid_dif.grid(row=8, column=1)
    humid_low_dif.grid(row=8, column=2)
    humid_mid_dif.grid(row=8, column=3)
    press_low_dif.grid(row=8, column=4)
    press_mid_dif.grid(row=8, column=5)

    password_old_label.grid(row=1, column=0)
    password_new_label.grid(row=2, column=0)
    def_sensor_location_entry_label.grid(row=3, column=0)
    def_temp_entry_label.grid(row=3, column=1)
    def_hum_entry_label.grid(row=3, column=2)
    def_press_entry_label.grid(row=3, column=3)

    temp_low_dif_label.grid(row=7, column=0)
    temp_mid_dif_label.grid(row=7, column=1)
    humid_low_dif_label.grid(row=7, column=2)
    humid_mid_dif_label.grid(row=7, column=3)
    press_low_dif_label.grid(row=7, column=4)
    press_mid_dif_label.grid(row=7, column=5)


    def_temp_entry.insert(0, username.def_temp)
    def_hum_entry.insert(0, username.def_hum)
    def_press_entry.insert(0, username.def_press)
    def_sensor_location_entry.insert(0, username.def_location)
        
def save_changes():
    """
    Saves changes from the settings window to DB
    """
    username.def_temp = def_temp_entry.get()
    username.def_hum= def_hum_entry.get()
    username.def_press= def_press_entry.get()
    username.def_location = def_sensor_location_entry.get()

    if password_old.get() is not None and password_old.get() == username.password:
        username.password = password_new.get()

    session.add(username)
    session.commit()

def sensors_window():
    """
    Draws the sensors window after a successful log in.
    """
    global pressure_val
    global temperature_val
    global humidity_val
    global location_val
    
   

    show_button = tk.Button(newWindow, text="Show Data From Sensors", command=show_data)
    save_data_button_json = tk.Button(newWindow, text="Save Data as JSON", command=save_data_json)
    save_data_button_db = tk.Button(newWindow, text="Save Data in Database", command=save_data_db)
    settings_button = tk.Button(newWindow, text="User Settings", command=user_settings)


    pressure_val = tk.Entry(newWindow, width = 30)
    temperature_val = tk.Entry(newWindow, width= 30)
    humidity_val = tk.Entry(newWindow, width= 30)
    location_val = tk.Entry(newWindow, width= 30)

    pressure_val_label = tk.Label(newWindow, text="Pressure Value hPa")
    temperature_val_label = tk.Label(newWindow, text="Temperature Value \u2103")
    humidity_val_label = tk.Label(newWindow, text="Humidity Value %")
    location_val_label = tk.Label(newWindow, text= "Location")

    pressure_val.grid(row = 2, column=1)
    temperature_val.grid(row = 1, column=1)
    humidity_val.grid(row = 3, column=1)
    location_val.grid(row= 4, column= 1)

    pressure_val_label.grid(row = 2, column=0)
    temperature_val_label.grid(row = 1, column=0)
    humidity_val_label.grid(row = 3, column=0)
    location_val_label.grid(row= 4, column= 0)
    
    show_button.grid(row = 5, column= 0)
    save_data_button_json.grid(row = 5, column= 1)
    save_data_button_db.grid(row= 5, column= 2)
    settings_button.grid(row=0, column=10)

    database_frame = tk.LabelFrame(newWindow, text= "Database Query", relief= "ridge")
    database_frame.grid(row=7 , column=0, columnspan=5)

    ############################ TIME AND CALENDAR + FRAME WIDGETS #####################################
    
    #combobox variables
    global hours_from
    global minutes_from
    global hours_to
    global minutes_to
    global calendar_from
    global calendar_to
    global graph_button

   
    hours_list = ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"]
    minutes_list = ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30",
                    "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59"]


    hours_from = tk.ttk.Combobox(database_frame)
    minutes_from = tk.ttk.Combobox(database_frame)
    hours_to = tk.ttk.Combobox(database_frame)
    minutes_to = tk.ttk.Combobox(database_frame)

    hours_from['values'] = hours_list
    hours_to['values'] = hours_list
    minutes_from['values'] = minutes_list
    minutes_to['values'] = minutes_list

    hours_from['state'] = 'readonly'
    hours_to['state'] = 'readonly'
    minutes_from['state'] = 'readonly'
    minutes_to['state'] = 'readonly'

    hours_from.set(hours_list[0])
    hours_to.set(hours_list[23])
    minutes_from.set(minutes_list[0])
    minutes_to.set(minutes_list[59])


    #end of combobox

    hours_from_label = tk.Label(database_frame, text="Hours from")
    minutes_from_label = tk.Label(database_frame, text="Minutes from")
    hours_to_label = tk.Label(database_frame, text="Hours to")
    minutes_to_label = tk.Label(database_frame, text="Minutes to")
    calendar_from_label = tk.Label(database_frame, text="Date from")
    calendar_to_label = tk.Label(database_frame, text="Date to")

    calendar_from = DateEntry(database_frame, locale='en_US', date_pattern='yyyy-MM-dd')
    calendar_to = DateEntry(database_frame, locale='en_US', date_pattern='yyyy-MM-dd')

    query_button = tk.Button(database_frame, text="Get Data", command=time_query)
    graph_button = tk.Button(database_frame, text="Show Graph", command=plot_graph, state=tk.DISABLED)    


    ###### GRID ######
    hours_from.grid(row=1 , column=0)
    minutes_from.grid(row=1, column=1)
    hours_to.grid(row=1, column=2)
    minutes_to.grid(row=1, column=3)

    hours_from_label.grid(row=0, column=0)
    minutes_from_label.grid(row=0, column=1)
    hours_to_label.grid(row=0, column=2)
    minutes_to_label.grid(row=0, column=3)
    calendar_from_label.grid(row=3, column=0)
    calendar_to_label.grid(row=3, column=2)

    calendar_from.grid(row=3, column= 1)
    calendar_to.grid(row=3, column=3)

    query_button.grid(row=0, column=4)
    graph_button.grid(row=3, column=5)


def time_query():
    """
    Gets values from the sensors window and makes a DB query based on the timewindow defined by the user
    """
    global qry
    
    h0 = hours_from.get()
    h1 = hours_to.get()
    m0 = minutes_from.get()
    m1 = minutes_to.get()
    time_from = h0 + ':' + m0
    time_to = h1 + ":" + m1


    
    date_from =calendar_from.get_date()
    date_to = calendar_to.get_date()
    
    all_from = str(date_from) + ' ' + time_from
    all_to = str(date_to) + ' ' + time_to

    final_from = datetime.strptime(all_from, "%Y-%m-%d %H:%M")
    final_to = datetime.strptime(all_to, "%Y-%m-%d %H:%M")

   

    qry = session.query(Data).filter(Data.user_id==username.id).filter(Data.date >= final_from).filter(Data.date <= final_to)

    if qry is not None:
        graph_button.configure(state=tk.NORMAL)

    

def plot_graph():
    """
    Plots graphs based upon the query received from the time query.
    """
    time_arr = [date.date for date in qry.all()]

    temp_arr = [float(temp.temp) for temp in qry.all()]
    humid_arr = [float(humid.humidity) for humid in qry.all()]
    pressure_arr = [float(press.pressure) for press in qry.all()]
  

    p1 = plt.subplot2grid((3, 3), (0, 0), colspan=2)
    p2 = plt.subplot2grid((3, 3), (0, 2), rowspan=3, colspan=2)
    p3 = plt.subplot2grid((3, 3), (1, 0), rowspan=2)

    p1.bar(time_arr, temp_arr, color = 'r', label = 'Temperature', width=0.5, edgecolor='black')
    p2.bar(time_arr, humid_arr, color = 'b', label = 'Humidity', width=0.5, edgecolor='black')
    p3.plot(time_arr, pressure_arr, color = 'g', label = 'Pressure')

    p1.set_ylim(min(temp_arr), max(temp_arr))
    p2.set_ylim(ymin=min(humid_arr), ymax=max(humid_arr))
    p3.set_ylim(ymin=min(pressure_arr), ymax=max(pressure_arr))

    plt.tight_layout()
    plt.legend()
    plt.show()
     
  

def show_data():
    """
    Receives data from sensors and prints out with colours depending on the difference from the user defined default values. 
    Green if difference is small.
    Yellow if it is medium.
    Red if it is large.
    """
    pressure_val.delete(0, tk.END)
    temperature_val.delete(0, tk.END)
    humidity_val.delete(0, tk.END)
    location_val.delete(0, tk.END)
    

    press_class_output = press_class.output()
    temp_class_output = temp_class.output()
    humid_class_output = humid_class.output()
    

    ######################################## CHANGE COLOUR OF ENTRY FIELDS BASED ON VALUES FROM SENSORS ###################################


    ############################### TEMPERATURE COLOUR ############################################
    if temp_class_output > username.def_temp + 5 and temp_class_output <= username.def_temp + 10 or temp_class_output < username.def_temp - 5 and temp_class_output >= username.def_temp - 10:
        temperature_val.configure({"background":"Yellow"})

    elif temp_class_output > username.def_temp + 10 or temp_class_output < username.def_temp - 10:
        temperature_val.configure({"background":"Red"})

    else:
        temperature_val.configure({"background":"Green"})


    ################################## HUMIDITY COLOUR #############################################
    if humid_class_output > username.def_hum + 10 and humid_class_output <= username.def_hum + 20 or humid_class_output < username.def_hum - 10 and humid_class_output >= username.def_hum - 20:
        humidity_val.configure({"background":"Yellow"})

    elif humid_class_output > username.def_hum + 20 or humid_class_output < username.def_hum - 20:
        humidity_val.configure({"background":"Red"})

    else:
        humidity_val.configure({"background":"Green"})

    ################################### PRESSURE COLOUR ###############################################
    if press_class_output > username.def_press + 10 and press_class_output <= username.def_press + 20 or press_class_output < username.def_press - 10 and press_class_output >= username.def_press - 20:
        pressure_val.configure({"background":"Yellow"})

    elif press_class_output > username.def_press + 20 or press_class_output < username.def_press - 20:
        pressure_val.configure({"background":"Red"})
    else:
        pressure_val.configure({"background":"Green"})
    
    ############################### INSERT VALUES FROM SENSORS #########################################
    pressure_val.insert(0, press_class_output)
    temperature_val.insert(0, temp_class_output)
    humidity_val.insert(0, humid_class_output)
    location_val.insert(0, username.def_location)

def save_data_json():
    """
    
    """
    data = save_as_dict(temperature_val.get(), pressure_val.get(), humidity_val.get(), date=str(datetime.today()), location="nesto")
    save_as_json(data)

def save_data_db():
    data = Data(location= location_val.get(), humidity= humidity_val.get(), temp=temperature_val.get(), pressure=pressure_val.get(), date=datetime.today(), user_id=username.id)
    session.add(data)
    session.commit()

def sign_up():
    global sign_up_w
    sign_up_w = tk.Toplevel(root)
    sign_up_w.geometry("800x600")
    sign_up_w.title("Create New User")

    global username_e_create
    global password_e_create
    global def_temp_entry
    global def_hum_entry
    global def_press_entry
    global def_sensor_location_entry

    def_temp_entry_label = tk.Label(sign_up_w, text="Default Temperature")
    def_hum_entry_label  = tk.Label(sign_up_w, text="Default Humidity")
    def_press_entry_label  = tk.Label(sign_up_w, text="Default Pressure")
    def_sensor_location_entry_label = tk.Label(sign_up_w, text="Sensor Location")
    

    username_e_create_label = tk.Label(sign_up_w, text="Username")
    password_e_create_label = tk.Label(sign_up_w, text= "Password")

    username_e_create = tk.Entry(sign_up_w)
    password_e_create = tk.Entry(sign_up_w, show="*")  
    def_temp_entry = tk.Entry(sign_up_w)
    def_hum_entry = tk.Entry(sign_up_w)
    def_press_entry = tk.Entry(sign_up_w)
    def_sensor_location_entry = tk.Entry(sign_up_w)

    def_temp_entry.insert(0, 25.00)
    def_hum_entry.insert(0, 70.00)
    def_press_entry.insert(0, 1013.00)
    def_sensor_location_entry.insert(0, "Karlovac")


    button_create = tk.Button(sign_up_w, text="Create", command=create_user, anchor=tk.CENTER)

    username_e_create.grid(row=0, column=1)
    password_e_create.grid(row=1, column=1)
    button_create.grid(row=2, column=1)

    def_temp_entry.grid(row=4, column=1)
    def_hum_entry.grid(row=4, column=2)
    def_press_entry.grid(row=4, column=3)
    def_sensor_location_entry.grid(row= 4, column= 0)
    

    username_e_create_label.grid(row=0, column=0)
    password_e_create_label.grid(row=1, column=0)
    def_sensor_location_entry_label.grid(row=3, column=0)
    def_temp_entry_label.grid(row=3, column=1)
    def_hum_entry_label.grid(row=3, column=2)
    def_press_entry_label.grid(row=3, column=3)


def create_user():
    new_user = User(username=username_e_create.get(), password = password_e_create.get(), def_temp= def_temp_entry.get(), def_hum=def_hum_entry.get(), def_press=def_press_entry.get(), def_location= def_sensor_location_entry.get())
    session.add(new_user)
    session.commit()
    sign_up_w.destroy()

    
########### FIRST SCREEN ############

###########DATA FOR WEATHER APP ############
#####LABELS######

temp = tk.Label(root, text=print_data_for_other_locations("Karlovac"))
username_e_label = tk.Label(root, text= "Username")
password_e_label = tk.Label(root, text= "Password")



location = tk.Entry(root)
location.insert(0, "Enter City")

username_e = tk.Entry(root)
password_e = tk.Entry(root, show="*")

login_b = tk.Button(root, text="Log In", command=log_in)
signup_b = tk.Button(root, text="Sign Up", command=sign_up)
get_weather_b = tk.Button(root, text="Get Data", command=change_weather_location)


#########GRID##########


temp.grid(row=0, column=2)
username_e_label.grid(row=2, column=0)
password_e_label.grid(row=3, column=0)


location.grid(row=0, column=0)

username_e.grid(row=2, column=1)
password_e.grid(row=3, column=1)

login_b.grid(row=4, column=1)
signup_b.grid(row=4, column=2)

get_weather_b.grid(row=0, column=1)

############## SIGN UP SCREEN #######################


root.mainloop()