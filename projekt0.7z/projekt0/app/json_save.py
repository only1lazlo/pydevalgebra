import json, os


#NAPISATI SPREMANJE PODATAKA OD SENZORA SA VREMENOM, DATUMOM I LOKACIJOM



def save_as_json(data_to_save):
    BASE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "ispis")
    file_name = os.path.join(BASE_DIR, "data.json")

    with open(file_name, "a") as file_to_write:  
        file_to_write.write(json.dumps(data_to_save, indent=4))


def save_as_dict(t, p, h, date, location):
    data_as_dict = {
        date: {"location":location,
                "temperature":t,
                "humidity":h,
                "pressure":p
    }}
    
    return data_as_dict