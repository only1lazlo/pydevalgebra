# Nakon što se korisnik ulogira aplikacija mora prikupiti podatke sa senzora za : vlažnost, temeperaturu i tlak.
#tablica useri, tablica prognoza - grad, datum, vlažnost, temperatura, tlak

import os
import datetime
import sqlalchemy as db
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

#Location of /data/ folder
BASE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")


conn = "sqlite:///" + os.path.join(BASE_DIR, 'database.sqlite')

engine = create_engine(conn, echo=True)

Base = declarative_base()


def get_hour():
    string = datetime.datetime.today()
    string = datetime.datetime.strftime(string, "%H")
    return string

def get_minute():
    string = datetime.datetime.today()
    string = datetime.datetime.strftime(string, "%M")
    return string

class User(Base):
    __tablename__ = "users"
    id = db.Column(db.Integer(), primary_key = True)
    username = db.Column(db.String(40), nullable = False, unique=True)
    password = db.Column(db.String(40), nullable = False)
    def_temp = db.Column(db.Float())
    def_hum = db.Column(db.Float())
    def_press = db.Column(db.Float())
    data = relationship("Data", backref="user")

class Data(Base):
    __tablename__ = "weather_data"
    id = db.Column(db.Integer(), primary_key=True)
    location = db.Column(db.String(40))
    humidity = db.Column(db.String(30))
    temp = db.Column(db.String(30))
    pressure = db.Column(db.String(30))
    date = db.Column(db.DateTime(), default=datetime.datetime.today)  
    # hour = db.Column(db.Integer, default=get_hour)
    # minute= db.Column(db.Integer(), default=get_minute)                
    user_id = db.Column(db.Integer(), db.ForeignKey("users.id"))



#Base.metadata.create_all(engine)
session = sessionmaker()(bind=engine)

# user = User(username="user", password="user")
# session.add(user)
# session.commit()