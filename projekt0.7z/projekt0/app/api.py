# Aplikacija korisniku koji nije ulogiran prikazuje datum, grad  po vašem odabiru i prognozu za njega dohvaćenu sa: Weather Forecast API | Open-Meteo.com
import datetime
import requests


URL = 'https://api.open-meteo.com/v1/forecast?latitude=45.83&longitude=15.98&hourly=temperature_2m,relativehumidity_2m,surface_pressure'

def get_data_from_url(url):
    try:
        response = requests.get(url)
        if response.status_code == requests.codes.ok:
            json_from_url = response.json()
        
        else:
            json_from_url = ''
    
    except Exception as e:
        print(f"Error: {e}")

    return json_from_url

json_data = get_data_from_url(URL)

#print(json_data)

date = datetime.datetime.now().isoformat()[0:14]
date= date + "00"
list_index = json_data["hourly"]["time"].index(date)
#print(list_index)

current_temp = json_data["hourly"]["temperature_2m"][list_index]
current_hum = json_data["hourly"]["relativehumidity_2m"][list_index]
current_pressure = json_data["hourly"]["surface_pressure"][list_index]

# print(current_hum)
# print(current_pressure)
# print(current_temp)