#  Projekt je:

# Napraviti aplikaciju koja će prikazivati podatke dobivene sa senzora i s interneta.


# Nakon što se korisnik ulogira aplikacija mora prikupiti podatke sa senzora za : vlažnost, temeperaturu i tlak.
# Ovisno o vrijednostima potrebno je naglastiti prelazi li vrijednost neku maksimlanu vrijednost (npr. temperatura je veća od 23 sutpnja C) 
# ili je vrijednost manaj od neke kritične( npr. tlak je ispod 1012 hPa)

# Aplikacija ima mogućnost i spremanja podataka u bazu, te ispis podataka u JSON datoteku.




# Folder u kojem je aplikacija
#    - folder ispis u koji će se spremati izlazna json datoteka



# Također, aplikacija podatke od senzora treba dobiti pozivanjem modula RaspberryPi u kojem ćete implementirati kalsu koja emulira RaspberryPi 
# i vraća podatek sa svih senzora koji su definirani (senzori su isto klase)



#prikaz podataka u obliku grafa pomoću matplotlib

import subprocess, sys, time
from RaspberryPi import cmd, t1
p = subprocess.run(cmd, shell=True)


print(f"varijabla je {t1}")


