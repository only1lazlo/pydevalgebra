# Aplikacija korisniku koji nije ulogiran prikazuje datum, grad  po vašem odabiru i prognozu za njega dohvaćenu sa: Weather Forecast API | Open-Meteo.com

import tkinter as tk
from api import print_data_for_other_locations
from database import session, User, Data
from RaspberryPi import temp_class, humid_class, press_class
from json_save import save_as_dict, save_as_json


root = tk.Tk()
root.title("WeatherApp")
root.geometry("800x600")

########## FUNKCIJE ##############
def log_in():
    """
    Checks if user exists. If no user exists, sends a message
    """
    global current_user
    global newWindow
    username = session.query(User).filter(User.username==username_e.get()).first()
    print("ovo je print")
    print(username.password)
    if not username:
        print("No specified username exists")
    elif  username.password != password_e.get():
        print("Wrong password")
    else:
        current_user = username.id
        newWindow = tk.Toplevel(root)
        print(current_user)
        check = tk.Label(newWindow, text="Uspjesan login")
        check.grid(row=0, column=0)
        sensors_window()

def change_weather_location():
    global temp
    temp.destroy()
    temp = tk.Label(root, text=print_data_for_other_locations(location.get()))
    temp.grid(row=0, column=1)


        

def sensors_window():
    global pressure_val
    global temperature_val
    global humidity_val

    show_button = tk.Button(newWindow, text="Show Data From Sensors", command=show_data)
    save_data_button_json = tk.Button(newWindow, text="Save Data as JSON", command=save_data_json)
    save_data_button_db = tk.Button(newWindow, text="Save Data in Database", command=save_data_db)


    pressure_val = tk.Entry(newWindow, width = 30)
    temperature_val = tk.Entry(newWindow, width= 30)
    humidity_val = tk.Entry(newWindow, width= 30)

    pressure_val.grid(row = 2, column=1)
    temperature_val.grid(row = 1, column=1)
    humidity_val.grid(row = 3, column=1)
    
    show_button.grid()
    save_data_button_json.grid()
    save_data_button_db.grid()

def show_data():
    pressure_val.delete(0, tk.END)
    temperature_val.delete(0, tk.END)
    humidity_val.delete(0, tk.END)
    
    pressure_val.insert(0, press_class.output())
    temperature_val.insert(0, temp_class.output())
    humidity_val.insert(0, humid_class.output())

def save_data_json():
    data = save_as_dict(temperature_val.get(), pressure_val.get(), humidity_val.get(), date="nesto", location="nesto")
    save_as_json(data)

def save_data_db():
    data = Data(location =None, humidity= humidity_val.get(), temp=temperature_val.get(), pressure=pressure_val.get(), date=None, user_id=current_user)
    session.add(data)
    session.commit()

def sign_up():
    global sign_up_w
    sign_up_w = tk.Toplevel(root)
    sign_up_w.geometry("800x600")
    sign_up_w.title("Create New User")

    global username_e_create
    global password_e_create

    username_e_create = tk.Entry(sign_up_w)
    password_e_create = tk.Entry(sign_up_w, show="*")  



    button_create = tk.Button(sign_up_w, text="Create", command=create_user, anchor=tk.CENTER)

    username_e_create.grid()
    password_e_create.grid()
    button_create.grid()

def create_user():
    new_user = User(username=username_e_create.get(), password = password_e_create.get())
    session.add(new_user)
    session.commit()
    sign_up_w.destroy()

    
########### FIRST SCREEN ############

###########DATA FOR WEATHER APP ############
#####LABELS######

temp = tk.Label(root, text=print_data_for_other_locations("Karlovac"))


location = tk.Entry(root)

username_e = tk.Entry(root)
password_e = tk.Entry(root, show="*")

login_b = tk.Button(root, text="Log In", command=log_in)
signup_b = tk.Button(root, text="Sign Up", command=sign_up)
get_weather_b = tk.Button(root, text="Get Data", command=change_weather_location)


#########GRID##########


temp.grid(row=0, column=1)


location.grid()

username_e.grid(row=2, column=0)
password_e.grid(row=3, column=0)

login_b.grid(row=4, column=0)
signup_b.grid(row=4, column=1)

get_weather_b.grid()

############## SIGN UP SCREEN #######################


root.mainloop()