import time
import random
import threading
import os




class Temp():
    def output(self):
        while True:
            #print(round(random.uniform(22, 25), 2))
            t1 = round(random.uniform(22, 25), 2)
            time.sleep(2)
            

class Humid():
    def output(self):
        while True:
            print(round(random.uniform(0, 100), 2))
            time.sleep(2)

class Press():
    def output(self):
        while True:
            print(round(random.uniform(1010, 1015), 2))
            time.sleep(2)



FILE_LOC = os.path.join(os.path.dirname(__file__), "RaspberryPi.py")



if __name__ == "__main__":
    temp = Temp()
    humid = Humid()
    press = Press()

    thread1 = threading.Thread(target=temp.output)
    thread1.start()

    thread2 = threading.Thread(target=humid.output)
    thread2.start()

    thread3 = threading.Thread(target=press.output)
    thread3.start()

    