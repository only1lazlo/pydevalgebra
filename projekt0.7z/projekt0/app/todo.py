
# Ovisno o vrijednostima potrebno je naglastiti prelazi li vrijednost neku maksimlanu vrijednost (npr. temperatura je veća od 23 sutpnja C) 
# ili je vrijednost manaj od neke kritične( npr. tlak je ispod 1012 hPa)




#prikaz podataka u obliku grafa pomoću matplotlib

# import subprocess, os, time, queue
# from RaspberryPi import FILE_LOC, value
# #p = subprocess.run(FILE_LOC, shell=True, capture_output=True)
# p = subprocess.run(FILE_LOC, shell=True)


# stdout = FILE_LOC.stdout.decode()
# # time.sleep(5)
# # p.os.kill()
# print(f"varijabla je {value}")



